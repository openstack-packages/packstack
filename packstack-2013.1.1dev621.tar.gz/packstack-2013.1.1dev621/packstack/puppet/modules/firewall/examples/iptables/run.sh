#!/bin/bash

puppet apply --debug --libdir ../../lib readme.pp
