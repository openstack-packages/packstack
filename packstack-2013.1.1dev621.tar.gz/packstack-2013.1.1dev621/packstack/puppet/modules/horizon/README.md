# OpenStack Dashboard

Puppet module for [Horizon](http://horizon.openstack.org/), the OpenStack Dashboard Project.

This version of the module is targeted at Folsom and Grizzly.
