# The nova module

This module can be used to flexibly configure [nova](http://nova.openstack.org/),
the compute service of openstack.

It has been tested with a combination of other modules, and has primarily been
developed as a subcomponent of the [openstack module](https://github.com/stackforge/puppet-openstack)

The examples that come with this module are out of date. It is recommended to use
the [openstack module](https://github.com/stackforge/puppet-openstack) as a starting place.
