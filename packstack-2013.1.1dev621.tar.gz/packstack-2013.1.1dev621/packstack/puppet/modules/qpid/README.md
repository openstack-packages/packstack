# qpid puppet module

very simple puppet module to install and start qpid
