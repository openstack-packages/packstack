require 'puppetlabs_spec_helper/module_spec_helper'

RSpec.configure do |c|
  c.alias_it_should_behave_like_to :it_configures, 'configures'
end
